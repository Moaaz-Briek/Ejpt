/*

eLearnSecurity 2013

*/

#include <iostream>
using namespace std;

int main()
{
	
	for (int x = 0; x <= 100; x++)
	{
    
     cout << x << ",";
     if (x == 10) break;
        
    }
	
	cin.ignore();
}

